culturalhistory = {"Ancient Warfare","Artefact","Balkanisation","Civil War","Crusade","Insurrection","Migration","Post Apocalyptic"}

--[[
1,Ancient Warfare
2,Artefact
3,Balkanisation
4,Civil War
5,Crusade
6,Insurrection
7,Migration
8,Post Apocalyptic

--creates the table
culturaltheme = {}
	--specifies each entry of the table, 
	culturaltheme[1] = {text = "**CULTURAL THEMES**", x = 755, y = 30}
	culturaltheme[2] = {text = "1. African", x = 755, y = 50}
	culturaltheme[3] = {text = "2. Ancient", x = 755, y = 70}
	culturaltheme[4] = {text = "3. Arabian", x = 755, y = 90}
	culturaltheme[5] = {text = "4. Barbarian", x = 755, y = 110}
	culturaltheme[6] = {text = "5. Feudal", x = 755, y = 130}
	culturaltheme[7] = {text = "6. Mercantile", x = 755, y = 150}
	culturaltheme[8] = {text = "7. Native American", x = 755, y = 170}
	culturaltheme[9] = {text = "8. Oriental", x = 755, y = 190}
	culturaltheme[10] = {text = "9. Renaissance", x = 755, y = 210}
	culturaltheme[11] = {text = "10. Post Renaissance", x = 755, y = 230}
	culturaltheme[12] = {text = "11. Savage", x = 755, y = 250}
	culturaltheme[13] = {text = "12. Seafaring", x = 755, y = 270}
	
	]]
	