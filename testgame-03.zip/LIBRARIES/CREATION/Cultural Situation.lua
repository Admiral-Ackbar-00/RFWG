--creates the table
culturalsituation = {}
	--specifies each entry of the table, 
	culturalsituation[1] = {text = "**CULTURAL SITUATIONS**", x = 755, y = 290}
	culturalsituation[2] = {text = "1. Class Dominance", x = 755, y = 310}
	culturalsituation[3] = {text = "2. Court", x = 755, y = 330}
	culturalsituation[4] = {text = "3. Chivalry", x = 755, y = 350}
	culturalsituation[5] = {text = "4. Deity", x = 755, y = 370}
	culturalsituation[6] = {text = "5. Dying World", x = 755, y = 390}
	culturalsituation[7] = {text = "6. Enemies", x = 755, y = 410}
	culturalsituation[8] = {text = "7. Exploration", x = 755, y = 430}
	culturalsituation[9] = {text = "8. Frontier", x = 755, y = 450}
	culturalsituation[10] = {text = "9. Magical", x = 755, y = 470}
	culturalsituation[11] = {text = "10. New World", x = 755, y = 490}
	culturalsituation[12] = {text = "11. Psionics", x = 755, y = 510}
	culturalsituation[13] = {text = "12. Race Dominance", x = 755, y = 530}
	culturalsituation[14] = {text = "13. Religious", x = 755, y = 550}
	culturalsituation[15] = {text = "14. Slavery", x = 755, y = 570}
	culturalsituation[16] = {text = "15. Technology", x = 755, y = 590}
	culturalsituation[17] = {text = "16. Warfare", x = 755, y = 610}
