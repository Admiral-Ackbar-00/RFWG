1,Caverns
2,Cites
3,Dungeons
4,Extraplanar
5,Fortress / strongholds
6,Ruins
7,Shrines
8,Wilderness
